package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.engine.TopicPipelineEngine
import com.example.data.models.AspectRatio
import com.example.data.models.BgmStyle
import com.example.data.models.CaptionStyle
import com.example.data.models.SupportedLanguage
import com.example.data.models.VideoDuration
import com.example.data.models.VisualAesthetic
import com.example.data.models.VoicePersona
import com.example.data.repository.TopicVideoRepository
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("TopicToVideo", appName)
    }

    @Test
    fun `test topic pipeline generation in Hindi`() {
        val project = TopicPipelineEngine.assembleCompleteVideo(
            topic = "ब्रह्मांड के रहस्य",
            duration = VideoDuration.SHORT_30S,
            aspectRatio = AspectRatio.VERTICAL_9_16,
            language = SupportedLanguage.HINDI,
            voicePersona = VoicePersona.WARM_STORYTELLER,
            visualStyle = VisualAesthetic.CINEMATIC_REALISM,
            bgmStyle = BgmStyle.CINEMATIC_WONDER,
            captionStyle = CaptionStyle.TIKTOK_BOUNCE,
            isDemoMode = true
        )

        assertEquals(3, project.scenes.size)
        assertEquals(VideoDuration.SHORT_30S, project.duration)
        assertEquals(AspectRatio.VERTICAL_9_16, project.aspectRatio)
        assertEquals(SupportedLanguage.HINDI, project.language)
        assertTrue(project.scenes[0].narrationText.contains("ब्रह्मांड के रहस्य"))
        assertNotNull(project.metadata.viralTitle)
        assertEquals(3, project.metadata.suggestedThumbnails.size)
    }

    @Test
    fun `test topic pipeline generation in Urdu`() {
        val project = TopicPipelineEngine.assembleCompleteVideo(
            topic = "قدیم تہذیبوں کے راز",
            duration = VideoDuration.SHORT_60S,
            aspectRatio = AspectRatio.VERTICAL_9_16,
            language = SupportedLanguage.URDU,
            voicePersona = VoicePersona.DEEP_DOCU,
            visualStyle = VisualAesthetic.VINTAGE_DOCU,
            bgmStyle = BgmStyle.SUSPENSE_MYSTERY,
            captionStyle = CaptionStyle.TIKTOK_BOUNCE,
            isDemoMode = true
        )

        assertEquals(5, project.scenes.size)
        assertEquals(SupportedLanguage.URDU, project.language)
        assertTrue(project.scenes[0].narrationText.contains("قدیم تہذیبوں کے راز"))
        assertTrue(project.metadata.viralTitle.contains("⚠️"))
    }

    @Test
    fun `test credit checks and spending limit in repository`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = TopicVideoRepository(context)

        // Initial credits should allow 30s video (25 credits)
        val (canAfford, _) = repo.canAffordGeneration(25)
        assertTrue(canAfford)

        // Attempting an impossible cost beyond balance
        val (canAffordHuge, reason) = repo.canAffordGeneration(99999)
        assertFalse(canAffordHuge)
        assertTrue(reason.contains("Insufficient credits"))

        // Add credit pack
        repo.addCreditPack(500, 7.0)
        assertEquals(125 + 500, repo.userProfile.value.creditsRemaining)
        assertEquals(7.0, repo.userProfile.value.currentSpendUsd, 0.01)

        // Upgrade plan
        val proPlan = repo.availablePlans.first { it.id == "plan_pro" }
        repo.processSubscriptionUpgrade(proPlan)
        assertEquals(proPlan.name, repo.userProfile.value.planType)
        assertTrue(repo.userProfile.value.isPaymentVerified)
    }
}
