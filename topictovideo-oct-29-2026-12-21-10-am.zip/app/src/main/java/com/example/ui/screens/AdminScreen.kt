package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ApiKeysConfig
import com.example.data.models.UserProfile
import com.example.ui.components.DemoModeBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.GlowingGradientButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.BrandAmber
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.BrandIndigoLight
import com.example.ui.theme.DemoModeBadgeBg
import com.example.ui.theme.DemoModeBadgeBorder
import com.example.ui.theme.DemoModeBadgeText
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AdminScreen(
    userProfile: UserProfile,
    onSaveApiKeys: (ApiKeysConfig) -> Unit,
    onUpdateSpendingCap: (Double) -> Unit
) {
    val context = LocalContext.current
    var geminiKey by remember { mutableStateOf(userProfile.apiKeysConfig.geminiApiKey) }
    var elevenLabsKey by remember { mutableStateOf(userProfile.apiKeysConfig.elevenLabsApiKey) }
    var pexelsKey by remember { mutableStateOf(userProfile.apiKeysConfig.pexelsApiKey) }
    var ffmpegWorkerUrl by remember { mutableStateOf(userProfile.apiKeysConfig.ffmpegWorkerUrl) }
    var demoModeOnly by remember { mutableStateOf(userProfile.apiKeysConfig.demoModeOnly) }

    var spendingCapInput by remember { mutableStateOf(userProfile.monthlySpendCapUsd.toString()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("admin_screen")
    ) {
        DemoModeBadge(detailed = true, modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(14.dp))

        // System Health & Queue Monitoring
        SectionHeader(
            title = "Rendering Queue & Pipeline Health",
            subtitle = "Distributed FFmpeg background workers & API latency"
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            GlassCard(modifier = Modifier.weight(1f)) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(BrandEmerald))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Queue Status", fontSize = 11.sp, color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Active (3 nodes)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BrandEmerald)
                    Text(text = "Avg wait: 0.6s", fontSize = 10.sp, color = TextMuted)
                }
            }

            GlassCard(modifier = Modifier.weight(1f)) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Speed, contentDescription = null, tint = BrandCyan, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Synthesizer Latency", fontSize = 11.sp, color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "120ms (P95)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BrandCyan)
                    Text(text = "Cache hit rate: 82%", fontSize = 10.sp, color = TextMuted)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Spending Cap & Credit Guard
        SectionHeader(
            title = "Cost Guard & Spending Caps",
            subtitle = "Hard stop limits to prevent unexpected cloud API bills"
        )

        Spacer(modifier = Modifier.height(8.dp))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Max Monthly API Spend Cap (USD)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(text = "Jobs auto-pause once budget is reached", fontSize = 11.sp, color = TextSecondary)
                    }
                    OutlinedTextField(
                        value = spendingCapInput,
                        onValueChange = {
                            spendingCapInput = it
                            it.toDoubleOrNull()?.let { cap -> onUpdateSpendingCap(cap) }
                        },
                        prefix = { Text("$", color = BrandCyan) },
                        modifier = Modifier.width(100.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandCyan,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Current Month Spend:", fontSize = 12.sp, color = TextSecondary)
                    Text(text = "$${userProfile.currentSpendUsd} / $${userProfile.monthlySpendCapUsd}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BrandEmerald)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Modular Service API Keys
        SectionHeader(
            title = "Modular Service API Connectors",
            subtitle = "Enable real multi-modal video generation services"
        )

        Spacer(modifier = Modifier.height(8.dp))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Enforce Demo Mode Only", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(text = "Bypasses external billing; uses simulated storyboard", fontSize = 11.sp, color = TextSecondary)
                    }
                    Switch(
                        checked = demoModeOnly,
                        onCheckedChange = { demoModeOnly = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = BrandAmber,
                            checkedTrackColor = DemoModeBadgeBg
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Gemini API Key
                Text(text = "1. Google Gemini API Key (Script & Storyboard)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = geminiKey,
                    onValueChange = { geminiKey = it },
                    placeholder = { Text("AIzaSy... (or inject via Secrets Panel)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrandIndigoLight,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // ElevenLabs TTS Key
                Text(text = "2. ElevenLabs / Speech API Key (Neural Voice)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = elevenLabsKey,
                    onValueChange = { elevenLabsKey = it },
                    placeholder = { Text("xi-... (Native Android TTS is used as fallback)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrandIndigoLight,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Pexels / Runway Key
                Text(text = "3. Video Media API Key (Pexels / Runway Gen-3)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = pexelsKey,
                    onValueChange = { pexelsKey = it },
                    placeholder = { Text("B-roll clip fetcher key") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrandIndigoLight,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // FFmpeg worker URL
                Text(text = "4. Server FFmpeg Worker Microservice Endpoint", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = ffmpegWorkerUrl,
                    onValueChange = { ffmpegWorkerUrl = it },
                    placeholder = { Text("https://render.yourdomain.com/v1/stitch") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrandIndigoLight,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val config = ApiKeysConfig(
                            geminiApiKey = geminiKey,
                            elevenLabsApiKey = elevenLabsKey,
                            pexelsApiKey = pexelsKey,
                            ffmpegWorkerUrl = ffmpegWorkerUrl,
                            demoModeOnly = demoModeOnly
                        )
                        onSaveApiKeys(config)
                        Toast.makeText(context, "API Configuration updated!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save Configuration")
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Complete Architecture & Deployment Documentation
        SectionHeader(
            title = "Pipeline Architecture & Setup Guide",
            subtitle = "Instructions for deploying the free-tier backend"
        )

        Spacer(modifier = Modifier.height(8.dp))

        val architectureGuide = """
# TopicToVideo Architecture & Production Deployment

## 1. Modular Services
- **LLM Engine**: Google Gemini 1.5 Flash (free tier 15 RPM) for Hook Script, Storyboarding, Subtitle time alignment, and SEO metadata.
- **Audio TTS**: ElevenLabs / OpenAI TTS with fallback to native on-device TTS.
- **Visual Assets**: Pexels Video API (free 200 req/hr) + Runway / Flux for AI video clips.
- **Video Compositor**: Cloud Run container with FFmpeg (scales to 0 when idle to stay 100% free-tier).
- **Storage**: Cloudflare R2 / AWS S3 (zero egress cost for video downloads).
- **Database & Auth**: Firebase / PostgreSQL with Row-Level Security.
- **Payments**: Stripe Checkout with Webhook handler for automated credit increments.

## 2. Required Environment Variables (.env)
```bash
GEMINI_API_KEY=AIzaSy...
ELEVENLABS_API_KEY=xi-...
PEXELS_API_KEY=...
FFMPEG_WORKER_URL=https://render-worker.internal
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
REDIS_URL=redis://default:...
```

## 3. End-to-End Verification Checklist
[✓] Step 1: User enters topic & selects 9:16 or 16:9
[✓] Step 2: Rate limit & credit balance pre-check
[✓] Step 3: LLM generates structured scene JSON script
[✓] Step 4: TTS generates synchronized voiceover
[✓] Step 5: FFmpeg worker composites video + Ken Burns + karaoke subs
[✓] Step 6: Webhook delivers completed MP4 CDN download link
        """.trimIndent()

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "System Blueprint & .env Specs", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    IconButton(onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Architecture Guide", architectureGuide))
                        Toast.makeText(context, "Architecture guide copied to clipboard!", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy guide", tint = BrandCyan, modifier = Modifier.size(18.dp))
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    color = Color.Black,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = architectureGuide,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF94A3B8),
                        modifier = Modifier.padding(10.dp),
                        lineHeight = 16.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
