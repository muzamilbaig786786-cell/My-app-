package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium SaaS Obsidian Dark Palette
val ObsidianBg = Color(0xFF090D16)
val ObsidianSurface = Color(0xFF101626)
val ObsidianSurfaceElevated = Color(0xFF161F36)
val ObsidianBorder = Color(0xFF232D48)

// Brand Vibrant Accents
val BrandIndigo = Color(0xFF6366F1)
val BrandIndigoLight = Color(0xFF818CF8)
val BrandIndigoDark = Color(0xFF4338CA)

val BrandCyan = Color(0xFF06B6D4)
val BrandCyanLight = Color(0xFF38BDF8)
val BrandCyanGlow = Color(0xFF22D3EE)

val BrandCoral = Color(0xFFF43F5E)
val BrandAmber = Color(0xFFF59E0B)
val BrandEmerald = Color(0xFF10B981)
val BrandPurple = Color(0xFFA855F7)

// Text tokens
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Demo tag & Warning
val DemoModeBadgeBg = Color(0xFF3B2508)
val DemoModeBadgeBorder = Color(0xFFF59E0B)
val DemoModeBadgeText = Color(0xFFFDE68A)

// Card Gradients
val GradientHeroStart = Color(0xFF1E1B4B)
val GradientHeroEnd = Color(0xFF0F172A)
