package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.VideoProject
import com.example.ui.components.DemoModeBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.GlowingGradientButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.BrandAmber
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.BrandIndigoLight
import com.example.ui.theme.BrandPurple
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LandingScreen(
    showcaseProjects: List<VideoProject>,
    onStartCreating: (String) -> Unit,
    onOpenProject: (VideoProject) -> Unit,
    onNavigatePricing: () -> Unit
) {
    var quickTopicInput by remember { mutableStateOf("The Mysterious Disappearance of Flight 19") }
    val scrollState = rememberScrollState()

    val sampleTrendingTopics = listOf(
        "Why Rome Really Fell",
        "How Quantum Computers Crack Passwords",
        "5 Hidden Caves Nobody Dares Enter",
        "The Dark Psychology of Casino Design",
        "سیاہ سوراخ کی پراسرار دنیا (Black Holes)"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("landing_screen")
    ) {
        // Top Demo Mode Banner
        DemoModeBadge(detailed = true, modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(16.dp))

        // Hero Section
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF1E1B4B).copy(alpha = 0.8f),
                            Color(0xFF0F172A).copy(alpha = 0.95f)
                        )
                    )
                )
                .border(1.dp, BrandIndigo.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    color = BrandIndigo.copy(alpha = 0.25f),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BrandIndigoLight.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = BrandCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Next-Gen AI Video Creator SaaS",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "One Topic → One Complete Video",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary,
                    textAlign = TextAlign.Center,
                    lineHeight = 32.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Type any topic. Get an original script, multi-lingual voiceover in Hindi, English & Urdu, animated karaoke subtitles, cinematic scenes, and viral packaging.",
                    fontSize = 14.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Interactive Instant Topic Teaser Input
                OutlinedTextField(
                    value = quickTopicInput,
                    onValueChange = { quickTopicInput = it },
                    label = { Text("Enter your video topic") },
                    placeholder = { Text("e.g. Secrets of the Mariana Trench") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("landing_topic_input"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrandIndigoLight,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedContainerColor = ObsidianSurfaceElevated,
                        unfocusedContainerColor = ObsidianSurfaceElevated,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Suggestion chips
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    sampleTrendingTopics.take(3).forEach { topic ->
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { quickTopicInput = topic },
                            color = ObsidianSurfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, ObsidianBorder)
                        ) {
                            Text(
                                text = topic,
                                fontSize = 11.sp,
                                color = TextSecondary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                GlowingGradientButton(
                    text = "Generate Complete Video Now",
                    icon = Icons.Default.Bolt,
                    onClick = { onStartCreating(quickTopicInput) },
                    testTag = "landing_generate_cta"
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Key Value Pillars
        SectionHeader(
            title = "Autonomous AI Video Pipeline",
            subtitle = "Everything handled from single prompt to final MP4"
        )

        Spacer(modifier = Modifier.height(12.dp))

        val pillars = listOf(
            Triple(
                Icons.Default.AutoAwesome,
                "Hook-Driven AI Script",
                "Algorithmic retention pacing with high-CTR hooks, narrative tension, and strong CTA."
            ),
            Triple(
                Icons.Default.VolumeUp,
                "Multi-Lingual AI Voiceover",
                "Natural cadence voices in Hindi, Urdu, English, Spanish, Arabic, and French."
            ),
            Triple(
                Icons.Default.Subtitles,
                "Dynamic Word-Level Subtitles",
                "TikTok viral bounce karaoke captions synced to speech frequency."
            ),
            Triple(
                Icons.Default.VideoLibrary,
                "9:16 Shorts & 16:9 YouTube",
                "Export vertical shorts for TikTok/Reels or landscape 4K for YouTube documentaries."
            )
        )

        pillars.forEach { (icon, title, desc) ->
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(BrandIndigo.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = icon, contentDescription = null, tint = BrandIndigoLight)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(text = desc, fontSize = 12.sp, color = TextSecondary, lineHeight = 17.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Showcase Gallery
        SectionHeader(
            title = "Generated Showcase Projects",
            subtitle = "Tap to open player and inspect storyboard scenes",
            badgeText = "Live Demos"
        )

        Spacer(modifier = Modifier.height(12.dp))

        showcaseProjects.forEach { project ->
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                onClick = { onOpenProject(project) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        Color(project.scenes.firstOrNull()?.visualGradients?.firstOrNull() ?: 0xFF1E1B4B),
                                        Color(project.scenes.firstOrNull()?.visualGradients?.lastOrNull() ?: 0xFF0284C7)
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${project.language.flag} ${project.language.englishName}",
                                fontSize = 11.sp,
                                color = BrandCyan,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "• ${project.aspectRatio.ratioLabel} • ${project.duration.label}",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = project.topic,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            maxLines = 1
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${project.scenes.size} Scenes • ${project.voicePersona.tone} Tone",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Creator Testimonials
        SectionHeader(
            title = "What Creators Are Saying",
            subtitle = "Used by automated channel runners & media agencies"
        )

        Spacer(modifier = Modifier.height(12.dp))

        val reviews = listOf(
            Triple(
                "Alex Rivera",
                "Faceless YouTube Channel (320k subs)",
                "“TopicToVideo cut our production time from 4 hours down to 90 seconds. The Hindi & Urdu voice generation allowed us to enter international markets instantly.”"
            ),
            Triple(
                "Priya Sharma",
                "TikTok & Shorts Creator",
                "“The TikTok bounce subtitles and auto-storyboard are insanely accurate. The thumbnails alone get a 14% CTR on my Shorts!”"
            )
        )

        reviews.forEach { (author, role, quote) ->
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        repeat(5) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = BrandAmber,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = quote, fontSize = 13.sp, color = TextPrimary, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = author, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BrandIndigoLight)
                    Text(text = role, fontSize = 11.sp, color = TextMuted)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Bottom CTA Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(BrandIndigo.copy(alpha = 0.3f), BrandCyan.copy(alpha = 0.3f))
                    )
                )
                .border(1.dp, BrandIndigoLight.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                .padding(20.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Ready to Build Your Video Empire?",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Start free with 100 credits. No credit card required.",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                GlowingGradientButton(
                    text = "Explore Plans & Pricing",
                    onClick = onNavigatePricing,
                    testTag = "landing_pricing_cta"
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
