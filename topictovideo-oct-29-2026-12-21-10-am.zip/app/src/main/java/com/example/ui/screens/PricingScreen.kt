package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.SubscriptionPlan
import com.example.data.models.UserProfile
import com.example.ui.components.DemoModeBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.GlowingGradientButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.BrandAmber
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.BrandIndigoLight
import com.example.ui.theme.DemoModeBadgeBg
import com.example.ui.theme.DemoModeBadgeBorder
import com.example.ui.theme.DemoModeBadgeText
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PricingScreen(
    userProfile: UserProfile,
    plans: List<SubscriptionPlan>,
    onUpgradePlan: (SubscriptionPlan) -> Unit,
    onAddCredits: (credits: Int, costUsd: Double) -> Unit
) {
    val context = LocalContext.current
    var isAnnualBilling by remember { mutableStateOf(true) }
    var planToCheckout by remember { mutableStateOf<SubscriptionPlan?>(null) }
    var isProcessingPayment by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("pricing_screen")
    ) {
        DemoModeBadge(detailed = true, modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(14.dp))

        // Heading
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Predictable SaaS Plans",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Fixed monthly credits. No hidden fees. Cancel anytime.",
                fontSize = 13.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Billing Cycle Toggle (Monthly vs Annual)
            Surface(
                color = ObsidianSurfaceElevated,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ObsidianBorder)
            ) {
                Row(
                    modifier = Modifier.padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (!isAnnualBilling) BrandIndigo else Color.Transparent,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.clickable { isAnnualBilling = false }
                    ) {
                        Text(
                            text = "Monthly Billing",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (!isAnnualBilling) Color.White else TextSecondary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }

                    Surface(
                        color = if (isAnnualBilling) BrandIndigo else Color.Transparent,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.clickable { isAnnualBilling = true }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "Annual (Save 20%)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isAnnualBilling) Color.White else TextSecondary
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Subscription Plans List
        plans.forEach { plan ->
            val isCurrentPlan = userProfile.planType == plan.name
            val price = if (isAnnualBilling) plan.priceAnnualMonthly else plan.priceMonthly

            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .testTag("plan_card_${plan.id}"),
                borderColor = if (plan.isPopular) BrandIndigoLight else ObsidianBorder
            ) {
                Column {
                    if (plan.isPopular) {
                        Surface(
                            color = BrandIndigo,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text(
                                text = "MOST POPULAR",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = plan.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = if (price == 0) "Free" else "$$price",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = if (price == 0) BrandEmerald else BrandCyan
                            )
                            if (price > 0) {
                                Text(text = "/mo", fontSize = 12.sp, color = TextMuted)
                            }
                        }
                    }

                    Text(
                        text = "${plan.creditsMonthly} credits/month • ${plan.maxResolution} • ${plan.maxVideoDuration}",
                        fontSize = 12.sp,
                        color = BrandIndigoLight,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Features checklist
                    plan.features.forEach { feat ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 2.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = BrandEmerald, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = feat, fontSize = 12.sp, color = TextSecondary)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (isCurrentPlan) {
                        Surface(
                            color = BrandEmerald.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BrandEmerald),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "CURRENT ACTIVE PLAN",
                                color = BrandEmerald,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )
                        }
                    } else {
                        GlowingGradientButton(
                            text = if (plan.priceMonthly == 0) "Stay on Free" else "Upgrade to ${plan.name}",
                            onClick = { planToCheckout = plan },
                            testTag = "checkout_button_${plan.id}"
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Credit Top-Up Packs
        SectionHeader(
            title = "Instant Credit Top-Up Packs",
            subtitle = "Need more credits without changing your plan tier?"
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            GlassCard(
                modifier = Modifier.weight(1f),
                onClick = {
                    onAddCredits(300, 5.0)
                    Toast.makeText(context, "+300 credits added to balance!", Toast.LENGTH_SHORT).show()
                }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(text = "+300 Credits", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = BrandCyan)
                    Text(text = "$5 USD", fontSize = 13.sp, color = TextPrimary)
                    Text(text = "(~8 Shorts)", fontSize = 10.sp, color = TextMuted)
                }
            }

            GlassCard(
                modifier = Modifier.weight(1f),
                onClick = {
                    onAddCredits(1000, 14.0)
                    Toast.makeText(context, "+1,000 credits added to balance!", Toast.LENGTH_SHORT).show()
                }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(text = "+1,000 Credits", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = BrandAmber)
                    Text(text = "$14 USD", fontSize = 13.sp, color = TextPrimary)
                    Text(text = "(~25 Shorts)", fontSize = 10.sp, color = TextMuted)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Refund & Cancellation Policy Notice
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = BrandEmerald, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(text = "14-Day Money-Back Guarantee", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(
                        text = "If you are not satisfied with generation quality, request a full refund within 14 days. Cancel membership anytime in one click.",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    // PAYMENT ADAPTER CHECKOUT MODAL
    if (planToCheckout != null) {
        val plan = planToCheckout!!
        val price = if (isAnnualBilling) plan.priceAnnualMonthly else plan.priceMonthly

        AlertDialog(
            onDismissRequest = { if (!isProcessingPayment) planToCheckout = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, tint = BrandCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Subscription Checkout", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
            },
            text = {
                Column {
                    Surface(
                        color = DemoModeBadgeBg,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DemoModeBadgeBorder.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "SANDBOX PAYMENT ADAPTER: Live payments require configured Stripe/Razorpay webhooks & merchant verification. No real money will be charged.",
                            fontSize = 11.sp,
                            color = DemoModeBadgeText,
                            modifier = Modifier.padding(8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = "Order Summary: ${plan.name}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(text = "Total: $$price / month (Billed ${if (isAnnualBilling) "Annually" else "Monthly"})", fontSize = 12.sp, color = BrandIndigoLight)
                    Text(text = "Includes: ${plan.creditsMonthly} credits/mo • ${plan.maxResolution}", fontSize = 11.sp, color = TextSecondary)

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(text = "Test Card Information (Never stores real PAN):", fontSize = 11.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(4.dp))

                    Surface(
                        color = ObsidianSurfaceElevated,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ObsidianBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Card: 4242 •••• •••• 4242 (Stripe Test)", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            Text(text = "Exp: 12/28 • CVC: 123", fontSize = 11.sp, color = TextSecondary)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isProcessingPayment = true
                        onUpgradePlan(plan)
                        Toast.makeText(context, "Successfully subscribed to ${plan.name}!", Toast.LENGTH_LONG).show()
                        planToCheckout = null
                        isProcessingPayment = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo)
                ) {
                    Text("Confirm Sandbox Payment")
                }
            },
            dismissButton = {
                TextButton(onClick = { planToCheckout = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = ObsidianSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}
