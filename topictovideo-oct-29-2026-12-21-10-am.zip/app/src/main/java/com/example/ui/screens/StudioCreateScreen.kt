package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CropLandscape
import androidx.compose.material.icons.filled.CropPortrait
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.AspectRatio
import com.example.data.models.BgmStyle
import com.example.data.models.CaptionStyle
import com.example.data.models.SupportedLanguage
import com.example.data.models.UserProfile
import com.example.data.models.VideoDuration
import com.example.data.models.VisualAesthetic
import com.example.data.models.VoicePersona
import com.example.ui.components.DemoModeBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.GlowingGradientButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.BrandAmber
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.BrandIndigoLight
import com.example.ui.theme.DemoModeBadgeBg
import com.example.ui.theme.DemoModeBadgeBorder
import com.example.ui.theme.DemoModeBadgeText
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudioCreateScreen(
    initialTopic: String = "",
    userProfile: UserProfile,
    onStartGeneration: (
        topic: String,
        duration: VideoDuration,
        aspectRatio: AspectRatio,
        language: SupportedLanguage,
        voicePersona: VoicePersona,
        visualStyle: VisualAesthetic,
        bgmStyle: BgmStyle,
        captionStyle: CaptionStyle
    ) -> Unit,
    onNavigatePricing: () -> Unit
) {
    var topic by remember {
        mutableStateOf(
            initialTopic.ifEmpty { "The Secret Origins of Ancient Pyramids" }
        )
    }

    var selectedDuration by remember { mutableStateOf(VideoDuration.SHORT_60S) }
    var selectedAspectRatio by remember { mutableStateOf(AspectRatio.VERTICAL_9_16) }
    var selectedLanguage by remember { mutableStateOf(SupportedLanguage.ENGLISH) }
    var selectedVoice by remember { mutableStateOf(VoicePersona.DEEP_DOCU) }
    var selectedVisual by remember { mutableStateOf(VisualAesthetic.CINEMATIC_REALISM) }
    var selectedBgm by remember { mutableStateOf(BgmStyle.SUSPENSE_MYSTERY) }
    var selectedCaptions by remember { mutableStateOf(CaptionStyle.TIKTOK_BOUNCE) }

    val randomPromptIdeas = listOf(
        "Why No One Can Explore Chernobyl Reactor 4",
        "How Coffee Conquered the Global Economy",
        "The Simulation Hypothesis Explained in 60s",
        "ہڑپہ تہذیب کے انوکھے راز (Indus Valley Mystery)",
        "क्या एलियंस सच में चांद पर रहते हैं?",
        "The Rise and Fall of the Silk Road"
    )

    val requiredCredits = selectedDuration.creditCost
    val canAfford = userProfile.creditsRemaining >= requiredCredits

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("studio_create_screen")
    ) {
        DemoModeBadge(detailed = true, modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(14.dp))

        // Topic Input Header
        SectionHeader(
            title = "1. Enter Video Topic",
            subtitle = "Type any topic or question. The AI builds the full video.",
            badgeText = "Core Engine"
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = topic,
            onValueChange = { topic = it },
            placeholder = { Text("e.g. Why Roman Concrete Lasted 2,000 Years") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("studio_topic_input"),
            shape = RoundedCornerShape(14.dp),
            trailingIcon = {
                IconButton(onClick = {
                    topic = randomPromptIdeas.random()
                }) {
                    Icon(
                        imageVector = Icons.Default.Shuffle,
                        contentDescription = "Random topic",
                        tint = BrandCyan
                    )
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandIndigoLight,
                unfocusedBorderColor = ObsidianBorder,
                focusedContainerColor = ObsidianSurfaceElevated,
                unfocusedContainerColor = ObsidianSurfaceElevated,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            minLines = 2,
            maxLines = 3
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Trending Topic Quick Chips
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            randomPromptIdeas.take(4).forEach { sample ->
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { topic = sample },
                    color = ObsidianSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, ObsidianBorder)
                ) {
                    Text(
                        text = sample,
                        fontSize = 11.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 2. Aspect Ratio Selector
        SectionHeader(
            title = "2. Select Format & Aspect Ratio",
            subtitle = "Optimized framing and typography safe areas"
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AspectRatio.values().forEach { ratio ->
                val isSelected = selectedAspectRatio == ratio
                GlassCard(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("aspect_ratio_${ratio.name}"),
                    borderColor = if (isSelected) BrandIndigoLight else ObsidianBorder,
                    onClick = { selectedAspectRatio = ratio }
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = when (ratio) {
                                AspectRatio.VERTICAL_9_16 -> Icons.Default.CropPortrait
                                AspectRatio.HORIZONTAL_16_9 -> Icons.Default.CropLandscape
                                AspectRatio.SQUARE_1_1 -> Icons.Default.CropSquare
                            },
                            contentDescription = ratio.label,
                            tint = if (isSelected) BrandCyan else TextMuted,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = ratio.ratioLabel,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) TextPrimary else TextSecondary
                        )
                        Text(
                            text = ratio.label,
                            fontSize = 11.sp,
                            color = if (isSelected) BrandIndigoLight else TextMuted
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 3. Duration Selector
        SectionHeader(
            title = "3. Video Duration",
            subtitle = "From quick viral shorts to deep dive documentaries"
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            VideoDuration.values().forEach { dur ->
                val isSelected = selectedDuration == dur
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .border(
                            1.dp,
                            if (isSelected) BrandIndigoLight else ObsidianBorder,
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { selectedDuration = dur }
                        .testTag("duration_${dur.name}"),
                    color = if (isSelected) BrandIndigo.copy(alpha = 0.2f) else ObsidianSurface
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp)
                    ) {
                        Text(
                            text = dur.label.split(" ").first(),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) TextPrimary else TextSecondary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${dur.creditCost} cr",
                            fontSize = 10.sp,
                            color = if (isSelected) BrandCyan else TextMuted
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 4. Language Selector
        SectionHeader(
            title = "4. Voice & Script Language",
            subtitle = "Native AI voice generation & localized scriptwriting"
        )

        Spacer(modifier = Modifier.height(8.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SupportedLanguage.values().forEach { lang ->
                val isSelected = selectedLanguage == lang
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .border(
                            1.dp,
                            if (isSelected) BrandCyan else ObsidianBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { selectedLanguage = lang }
                        .testTag("lang_${lang.code}"),
                    color = if (isSelected) BrandCyan.copy(alpha = 0.15f) else ObsidianSurface
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = lang.flag, fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${lang.englishName} (${lang.nativeName})",
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) TextPrimary else TextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 5. Voice Persona & Visual Style
        SectionHeader(
            title = "5. Voice Persona & Visual Style",
            subtitle = "Select AI tone and image generation prompt aesthetics"
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Voice Persona List
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            VoicePersona.values().forEach { voice ->
                val isSelected = selectedVoice == voice
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (isSelected) BrandIndigoLight else ObsidianBorder,
                    onClick = { selectedVoice = voice }
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = if (isSelected) BrandCyan else TextMuted
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = voice.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) TextPrimary else TextSecondary
                            )
                            Text(
                                text = voice.description,
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Selected",
                                tint = BrandEmerald,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Visual Aesthetic
        Text(text = "Visual Aesthetic", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(modifier = Modifier.height(6.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            VisualAesthetic.values().forEach { aesthetic ->
                val isSelected = selectedVisual == aesthetic
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .border(
                            1.dp,
                            if (isSelected) BrandIndigoLight else ObsidianBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { selectedVisual = aesthetic },
                    color = if (isSelected) BrandIndigo.copy(alpha = 0.2f) else ObsidianSurface
                ) {
                    Text(
                        text = aesthetic.title,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) TextPrimary else TextSecondary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 6. BGM & Subtitles
        SectionHeader(
            title = "6. Background Music & Captions Style",
            subtitle = "Viral subtitle animations & atmospheric score"
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Caption Style Box
            GlassCard(
                modifier = Modifier.weight(1f),
                borderColor = BrandIndigoLight.copy(alpha = 0.6f)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Subtitles, contentDescription = null, tint = BrandCyan, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Captions", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = selectedCaptions.title, fontSize = 12.sp, color = BrandIndigoLight, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    CaptionStyle.values().forEach { cap ->
                        if (cap != selectedCaptions) {
                            Text(
                                text = "• ${cap.title}",
                                fontSize = 11.sp,
                                color = TextMuted,
                                modifier = Modifier
                                    .padding(vertical = 2.dp)
                                    .clickable { selectedCaptions = cap }
                            )
                        }
                    }
                }
            }

            // BGM Style Box
            GlassCard(
                modifier = Modifier.weight(1f),
                borderColor = BrandCyan.copy(alpha = 0.4f)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.MusicNote, contentDescription = null, tint = BrandAmber, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Music Mood", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = selectedBgm.title, fontSize = 12.sp, color = BrandCyan, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    BgmStyle.values().take(3).forEach { bgm ->
                        if (bgm != selectedBgm) {
                            Text(
                                text = "• ${bgm.title}",
                                fontSize = 11.sp,
                                color = TextMuted,
                                modifier = Modifier
                                    .padding(vertical = 2.dp)
                                    .clickable { selectedBgm = bgm }
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Pre-generation Cost Calculation Card
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = if (canAfford) BrandEmerald.copy(alpha = 0.4f) else BrandAmber.copy(alpha = 0.6f)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Pre-Generation Cost Estimate", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(
                        text = "$requiredCredits Credits",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = if (canAfford) BrandEmerald else BrandAmber
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Your Current Balance:", fontSize = 12.sp, color = TextSecondary)
                    Text(
                        text = "${userProfile.creditsRemaining} Credits",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Scenes to Generate:", fontSize = 12.sp, color = TextSecondary)
                    Text(
                        text = "${selectedDuration.sceneCount} Timed Scenes",
                        fontSize = 12.sp,
                        color = TextPrimary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Resolution Target:", fontSize = 12.sp, color = TextSecondary)
                    Text(
                        text = if (selectedAspectRatio == AspectRatio.VERTICAL_9_16) "1080x1920 (9:16 Shorts)" else "1920x1080 (16:9 Landscape)",
                        fontSize = 12.sp,
                        color = BrandCyan
                    )
                }

                if (!canAfford) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = BrandAmber, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Insufficient credits. Top-up or upgrade plan.",
                            fontSize = 12.sp,
                            color = BrandAmber
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (canAfford) {
            GlowingGradientButton(
                text = "Generate Complete Video ($requiredCredits Credits)",
                icon = Icons.Default.Bolt,
                onClick = {
                    onStartGeneration(
                        topic,
                        selectedDuration,
                        selectedAspectRatio,
                        selectedLanguage,
                        selectedVoice,
                        selectedVisual,
                        selectedBgm,
                        selectedCaptions
                    )
                },
                testTag = "studio_generate_button"
            )
        } else {
            GlowingGradientButton(
                text = "Upgrade Plan / Get Credits",
                icon = Icons.Default.Bolt,
                onClick = onNavigatePricing,
                testTag = "studio_upgrade_button"
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
