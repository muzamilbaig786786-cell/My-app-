package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.VideoAudioEngine
import com.example.data.models.AspectRatio
import com.example.data.models.CaptionStyle
import com.example.data.models.SceneItem
import com.example.data.models.VideoProject
import com.example.ui.components.DemoModeBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.GlowingGradientButton
import com.example.ui.theme.BrandAmber
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.BrandIndigoLight
import com.example.ui.theme.BrandPurple
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

@Composable
fun VideoPlayerScreen(
    project: VideoProject,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val audioEngine = remember { VideoAudioEngine(context) }

    DisposableEffect(Unit) {
        onDispose {
            audioEngine.stop()
            audioEngine.release()
        }
    }

    var isPlaying by remember { mutableStateOf(false) }
    var currentSceneIndex by remember { mutableIntStateOf(0) }
    var playbackProgressSeconds by remember { mutableStateOf(0f) }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Player & Storyboard, 1: Script & Audio, 2: Thumbnails & SEO
    var playerAspectRatio by remember { mutableStateOf(project.aspectRatio) }

    val totalDurationSeconds = project.duration.seconds
    val scenes = project.scenes
    val activeScene = scenes.getOrElse(currentSceneIndex) { scenes.first() }

    // Automatic playback loop
    LaunchedEffect(isPlaying, currentSceneIndex) {
        if (isPlaying) {
            val scene = scenes[currentSceneIndex]
            audioEngine.speakScene(scene.narrationText, project.language)
            val stepDelay = 200L
            val totalSteps = (scene.durationSeconds * 1000 / stepDelay).toInt()

            for (step in 0..totalSteps) {
                if (!isPlaying) break
                delay(stepDelay)
                playbackProgressSeconds = (currentSceneIndex * scene.durationSeconds) + (step * (stepDelay / 1000f))
            }

            if (isPlaying) {
                if (currentSceneIndex < scenes.size - 1) {
                    currentSceneIndex++
                } else {
                    // Loop or end
                    isPlaying = false
                    currentSceneIndex = 0
                    playbackProgressSeconds = 0f
                }
            }
        } else {
            audioEngine.stop()
        }
    }

    // Motion animation transition for scene canvas
    val infiniteTransition = rememberInfiniteTransition(label = "motion")
    val zoomScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "kenBurnsZoom"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("video_player_screen")
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = {
                audioEngine.stop()
                onBack()
            }) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }
            Text(
                text = project.topic,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            // Aspect switch toggle
            IconButton(onClick = {
                playerAspectRatio = if (playerAspectRatio == AspectRatio.VERTICAL_9_16) {
                    AspectRatio.HORIZONTAL_16_9
                } else {
                    AspectRatio.VERTICAL_9_16
                }
            }) {
                Icon(
                    imageVector = Icons.Default.Fullscreen,
                    contentDescription = "Switch aspect ratio",
                    tint = BrandCyan
                )
            }
        }

        DemoModeBadge(detailed = false, modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(12.dp))

        // THE VIDEO PLAYER CANVAS
        val playerRatio = if (playerAspectRatio == AspectRatio.VERTICAL_9_16) 9f / 16f else 16f / 9f

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (playerAspectRatio == AspectRatio.VERTICAL_9_16) {
                        Modifier.height(440.dp)
                    } else {
                        Modifier.aspectRatio(16f / 9f)
                    }
                )
                .clip(RoundedCornerShape(20.dp))
                .border(2.dp, BrandIndigoLight.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                .background(Color.Black)
                .testTag("video_player_canvas"),
            contentAlignment = Alignment.Center
        ) {
            // Dynamic Ken Burns Motion Scene Canvas
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .scale(if (isPlaying) zoomScale else 1.0f)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(activeScene.visualGradients.first()),
                                Color(activeScene.visualGradients.last())
                            )
                        )
                    )
            )

            // Scene Watermark / Demo watermark
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "TopicToVideo Demo",
                    fontSize = 10.sp,
                    color = BrandCyan,
                    fontWeight = FontWeight.Bold
                )
            }

            // Top Camera & Scene Angle Tag
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "Scene ${activeScene.sceneNumber}/${scenes.size} • ${activeScene.cameraAngle}",
                    fontSize = 10.sp,
                    color = TextPrimary
                )
            }

            // LIVE SUBTITLE OVERLAY (Rendered dynamically in selected style!)
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 16.dp, vertical = 24.dp)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                when (project.captionStyle) {
                    CaptionStyle.TIKTOK_BOUNCE -> {
                        Surface(
                            color = Color.Black.copy(alpha = 0.75f),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BrandAmber)
                        ) {
                            Text(
                                text = activeScene.narrationText,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = BrandAmber,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                lineHeight = 18.sp
                            )
                        }
                    }
                    CaptionStyle.KARAOKE_NEON -> {
                        Surface(
                            color = Color.Black.copy(alpha = 0.7f),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BrandCyan)
                        ) {
                            Text(
                                text = activeScene.narrationText,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrandCyan,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                    else -> {
                        Surface(
                            color = Color.Black.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = activeScene.narrationText,
                                fontSize = 13.sp,
                                color = Color.White,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Play Overlay Button when paused
            if (!isPlaying) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(BrandIndigo.copy(alpha = 0.85f))
                        .clickable { isPlaying = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Transport Controls Bar
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                // Timeline Slider
                Slider(
                    value = playbackProgressSeconds,
                    onValueChange = { targetSec ->
                        playbackProgressSeconds = targetSec
                        val sceneLen = totalDurationSeconds / scenes.size
                        currentSceneIndex = (targetSec / sceneLen).toInt().coerceIn(0, scenes.size - 1)
                    },
                    valueRange = 0f..totalDurationSeconds.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = BrandCyan,
                        activeTrackColor = BrandIndigoLight,
                        inactiveTrackColor = ObsidianBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "00:${playbackProgressSeconds.toInt().toString().padStart(2, '0')}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "00:${totalDurationSeconds.toString().padStart(2, '0')}",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        currentSceneIndex = (currentSceneIndex - 1).coerceAtLeast(0)
                        playbackProgressSeconds = (currentSceneIndex * (totalDurationSeconds / scenes.size)).toFloat()
                    }) {
                        Icon(imageVector = Icons.Default.FastRewind, contentDescription = "Prev Scene", tint = TextPrimary)
                    }

                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(BrandIndigo)
                            .clickable { isPlaying = !isPlaying }
                            .testTag("player_toggle_play"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White
                        )
                    }

                    IconButton(onClick = {
                        currentSceneIndex = (currentSceneIndex + 1).coerceAtMost(scenes.size - 1)
                        playbackProgressSeconds = (currentSceneIndex * (totalDurationSeconds / scenes.size)).toFloat()
                    }) {
                        Icon(imageVector = Icons.Default.FastForward, contentDescription = "Next Scene", tint = TextPrimary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Tabs: Storyboard / Script & Voice / Metadata & Thumbnails
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = ObsidianSurface,
            contentColor = BrandCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = BrandCyan
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Storyboard", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Script & Voice", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("SEO & Covers", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // TAB 0: SCENE STORYBOARD
        if (selectedTab == 0) {
            Text(
                text = "Scene-by-Scene Storyboard (${scenes.size} Scenes)",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            scenes.forEachIndexed { index, scene ->
                val isCurrent = index == currentSceneIndex
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    borderColor = if (isCurrent) BrandCyan else ObsidianBorder,
                    onClick = {
                        currentSceneIndex = index
                        playbackProgressSeconds = (index * (totalDurationSeconds / scenes.size)).toFloat()
                    }
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (isCurrent) BrandCyan else ObsidianSurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${scene.sceneNumber}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isCurrent) Color.Black else TextSecondary
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = scene.headline,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${scene.durationSeconds}s",
                                    fontSize = 11.sp,
                                    color = BrandIndigoLight
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = scene.narrationText,
                                fontSize = 12.sp,
                                color = TextSecondary,
                                maxLines = 2
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Prompt: ${scene.visualPrompt}",
                                fontSize = 10.sp,
                                color = TextMuted,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // TAB 1: SCRIPT & VOICE
        if (selectedTab == 1) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Full Generated Script", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        IconButton(onClick = {
                            val fullScript = scenes.joinToString("\n\n") { "Scene ${it.sceneNumber} (${it.durationSeconds}s): ${it.narrationText}" }
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Script", fullScript))
                            Toast.makeText(context, "Full script copied to clipboard!", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy script", tint = BrandCyan)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    scenes.forEach { sc ->
                        Text(
                            text = "[Scene ${sc.sceneNumber} - ${sc.headline}]",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandIndigoLight
                        )
                        Text(
                            text = sc.narrationText,
                            fontSize = 13.sp,
                            color = TextPrimary,
                            lineHeight = 18.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }
            }
        }

        // TAB 2: SEO & THUMBNAILS
        if (selectedTab == 2) {
            Column {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Viral Video Title (CTR: ${project.metadata.hookScore}%)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            IconButton(onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Title", project.metadata.viralTitle))
                                Toast.makeText(context, "Title copied!", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = BrandCyan, modifier = Modifier.size(18.dp))
                            }
                        }
                        Text(
                            text = project.metadata.viralTitle,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandAmber
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Estimated Performance: ${project.metadata.estimatedRetention}",
                            fontSize = 11.sp,
                            color = BrandEmerald
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Hashtags
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Optimized Hashtags", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            IconButton(onClick = {
                                val tags = project.metadata.hashtags.joinToString(" ")
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Tags", tags))
                                Toast.makeText(context, "Tags copied!", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = BrandCyan, modifier = Modifier.size(18.dp))
                            }
                        }
                        Text(
                            text = project.metadata.hashtags.joinToString(" "),
                            fontSize = 12.sp,
                            color = BrandIndigoLight,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Generated Thumbnails
                Text(text = "Generated Thumbnails (3 Variations)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(modifier = Modifier.height(8.dp))

                project.metadata.suggestedThumbnails.forEach { thumb ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(thumb.gradientStart), Color(thumb.gradientEnd))
                                )
                            )
                            .border(1.dp, BrandAmber.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Surface(
                                color = BrandAmber,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = thumb.badge,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.Black,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = thumb.headline,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            Text(
                                text = thumb.subtext,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Yellow
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Export Actions
        GlowingGradientButton(
            text = "Export & Download MP4 Package",
            icon = Icons.Default.Download,
            onClick = {
                Toast.makeText(
                    context,
                    "Saved '${project.title}.mp4' to downloads with synchronized subtitles & audio track!",
                    Toast.LENGTH_LONG
                ).show()
            },
            testTag = "export_download_button"
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}
