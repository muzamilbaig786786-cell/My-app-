package com.example.data.repository

import android.content.Context
import com.example.data.engine.TopicPipelineEngine
import com.example.data.models.ApiKeysConfig
import com.example.data.models.AspectRatio
import com.example.data.models.BgmStyle
import com.example.data.models.CaptionStyle
import com.example.data.models.PipelineStep
import com.example.data.models.SubscriptionPlan
import com.example.data.models.SupportedLanguage
import com.example.data.models.UserProfile
import com.example.data.models.VideoDuration
import com.example.data.models.VideoProject
import com.example.data.models.VisualAesthetic
import com.example.data.models.VoicePersona
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class TopicVideoRepository(private val context: Context) {

    private val _projects = MutableStateFlow<List<VideoProject>>(emptyList())
    val projects: StateFlow<List<VideoProject>> = _projects.asStateFlow()

    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _currentJobStep = MutableStateFlow<PipelineStep?>(null)
    val currentJobStep: StateFlow<PipelineStep?> = _currentJobStep.asStateFlow()

    private val _currentJobProgress = MutableStateFlow(0f)
    val currentJobProgress: StateFlow<Float> = _currentJobProgress.asStateFlow()

    private val _currentJobLog = MutableStateFlow("")
    val currentJobLog: StateFlow<String> = _currentJobLog.asStateFlow()

    val availablePlans = listOf(
        SubscriptionPlan(
            id = "plan_free",
            name = "Starter Free",
            priceMonthly = 0,
            priceAnnualMonthly = 0,
            creditsMonthly = 100,
            maxResolution = "720p HD",
            maxVideoDuration = "60s Shorts",
            maxConcurrentJobs = 1,
            hasWatermark = true,
            features = listOf(
                "100 AI credits per month",
                "9:16 Shorts & Reels format",
                "Standard voiceover & subtitles",
                "Community support",
                "Subtle watermark on export"
            )
        ),
        SubscriptionPlan(
            id = "plan_pro",
            name = "Creator Pro",
            priceMonthly = 19,
            priceAnnualMonthly = 15,
            creditsMonthly = 1500,
            maxResolution = "1080p Full HD",
            maxVideoDuration = "5 Minutes",
            maxConcurrentJobs = 3,
            hasWatermark = false,
            features = listOf(
                "1,500 AI credits monthly (~40 Shorts)",
                "Both 9:16 Vertical & 16:9 Landscape",
                "Full HD 1080p, Zero watermark",
                "All 8 languages + Ultra-realistic voices",
                "Animated TikTok bounce subtitles",
                "Commercial use license",
                "High-priority render queue"
            ),
            isPopular = true
        ),
        SubscriptionPlan(
            id = "plan_agency",
            name = "Studio Agency",
            priceMonthly = 59,
            priceAnnualMonthly = 49,
            creditsMonthly = 6000,
            maxResolution = "4K UHD",
            maxVideoDuration = "8 Minutes",
            maxConcurrentJobs = 10,
            hasWatermark = false,
            features = listOf(
                "6,000 AI credits (~180 videos)",
                "4K Ultra HD Export rendering",
                "Up to 8-minute deep-dive documentaries",
                "Custom brand voice clone upload",
                "FFmpeg raw asset export & SRT files",
                "Dedicated server queue with zero latency",
                "API webhooks & multi-seat access"
            )
        )
    )

    init {
        seedInitialProjects()
    }

    private fun seedInitialProjects() {
        // Pre-populate with realistic showcase projects to demonstrate capabilities
        val bermudaProject = TopicPipelineEngine.assembleCompleteVideo(
            topic = "The Mystery of the Bermuda Triangle",
            duration = VideoDuration.SHORT_60S,
            aspectRatio = AspectRatio.VERTICAL_9_16,
            language = SupportedLanguage.ENGLISH,
            voicePersona = VoicePersona.DEEP_DOCU,
            visualStyle = VisualAesthetic.CINEMATIC_REALISM,
            bgmStyle = BgmStyle.SUSPENSE_MYSTERY,
            captionStyle = CaptionStyle.TIKTOK_BOUNCE,
            isDemoMode = true
        )

        val aiDevProject = TopicPipelineEngine.assembleCompleteVideo(
            topic = "5 AI Tools That Will Replace Junior Developers",
            duration = VideoDuration.LONG_3MIN,
            aspectRatio = AspectRatio.HORIZONTAL_16_9,
            language = SupportedLanguage.ENGLISH,
            voicePersona = VoicePersona.TECH_EXPLAINER,
            visualStyle = VisualAesthetic.CYBERPUNK_NEON,
            bgmStyle = BgmStyle.SYNTHWAVE_ENERGY,
            captionStyle = CaptionStyle.MINIMAL_CLEAN,
            isDemoMode = true
        )

        val silkRoadHindi = TopicPipelineEngine.assembleCompleteVideo(
            topic = "प्राचीन सिल्क रूट का खोया हुआ इतिहास",
            duration = VideoDuration.SHORT_60S,
            aspectRatio = AspectRatio.VERTICAL_9_16,
            language = SupportedLanguage.HINDI,
            voicePersona = VoicePersona.WARM_STORYTELLER,
            visualStyle = VisualAesthetic.VINTAGE_DOCU,
            bgmStyle = BgmStyle.CINEMATIC_WONDER,
            captionStyle = CaptionStyle.TIKTOK_BOUNCE,
            isDemoMode = true
        )

        _projects.value = listOf(bermudaProject, aiDevProject, silkRoadHindi)
    }

    fun canAffordGeneration(cost: Int): Pair<Boolean, String> {
        val current = _userProfile.value
        if (current.creditsRemaining < cost) {
            return false to "Insufficient credits (${current.creditsRemaining} available, requires $cost). Please upgrade or top-up credits."
        }
        if (current.currentSpendUsd >= current.monthlySpendCapUsd) {
            return false to "Monthly spending cap reached (\$${current.monthlySpendCapUsd}). Adjust in Admin Settings."
        }
        return true to "OK"
    }

    suspend fun generateNewVideo(
        topic: String,
        duration: VideoDuration,
        aspectRatio: AspectRatio,
        language: SupportedLanguage,
        voicePersona: VoicePersona,
        visualStyle: VisualAesthetic,
        bgmStyle: BgmStyle,
        captionStyle: CaptionStyle,
        isDemoMode: Boolean = true
    ): VideoProject {
        // Deduct credits
        val cost = duration.creditCost
        _userProfile.value = _userProfile.value.let {
            it.copy(
                creditsRemaining = (it.creditsRemaining - cost).coerceAtLeast(0),
                storageUsedMb = it.storageUsedMb + (duration.seconds * 1.5).toInt()
            )
        }

        val project = TopicPipelineEngine.executePipeline(
            topic = topic,
            duration = duration,
            aspectRatio = aspectRatio,
            language = language,
            voicePersona = voicePersona,
            visualStyle = visualStyle,
            bgmStyle = bgmStyle,
            captionStyle = captionStyle,
            isDemoMode = isDemoMode
        ) { step, progress, log ->
            _currentJobStep.value = step
            _currentJobProgress.value = progress
            _currentJobLog.value = log
        }

        _projects.value = listOf(project) + _projects.value
        _currentJobStep.value = null
        return project
    }

    fun deleteProject(projectId: String) {
        _projects.value = _projects.value.filter { it.id != projectId }
    }

    fun updateApiKeys(config: ApiKeysConfig) {
        _userProfile.value = _userProfile.value.copy(apiKeysConfig = config)
    }

    fun updateSpendingCap(cap: Double) {
        _userProfile.value = _userProfile.value.copy(monthlySpendCapUsd = cap)
    }

    // Payment Adapter Simulation
    fun processSubscriptionUpgrade(plan: SubscriptionPlan): Boolean {
        _userProfile.value = _userProfile.value.copy(
            planType = plan.name,
            creditsRemaining = _userProfile.value.creditsRemaining + plan.creditsMonthly,
            creditsMonthlyMax = plan.creditsMonthly,
            isPaymentVerified = true
        )
        return true
    }

    fun addCreditPack(credits: Int, costUsd: Double): Boolean {
        _userProfile.value = _userProfile.value.let {
            it.copy(
                creditsRemaining = it.creditsRemaining + credits,
                currentSpendUsd = it.currentSpendUsd + costUsd
            )
        }
        return true
    }
}
