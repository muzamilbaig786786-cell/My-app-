package com.example.data.models

enum class AspectRatio(val label: String, val ratioLabel: String, val iconName: String, val targetPlatforms: String) {
    VERTICAL_9_16("Vertical", "9:16", "phone", "Shorts, Reels, TikTok"),
    HORIZONTAL_16_9("Widescreen", "16:9", "tv", "YouTube, Landscape TV"),
    SQUARE_1_1("Square", "1:1", "crop_square", "Instagram Feed, LinkedIn")
}

enum class VideoDuration(val label: String, val seconds: Int, val sceneCount: Int, val creditCost: Int) {
    SHORT_30S("30s Short", 30, 3, 25),
    SHORT_60S("60s Short", 60, 5, 40),
    LONG_3MIN("3 Min Story", 180, 10, 120),
    LONG_5MIN("5 Min Deep Dive", 300, 15, 180),
    LONG_8MIN("8 Min Documentary", 480, 22, 260)
}

enum class SupportedLanguage(val code: String, val englishName: String, val nativeName: String, val flag: String) {
    ENGLISH("en", "English", "English (US)", "🇺🇸"),
    HINDI("hi", "Hindi", "हिन्दी", "🇮🇳"),
    URDU("ur", "Urdu", "اردو", "🇵🇰"),
    SPANISH("es", "Spanish", "Español", "🇪🇸"),
    ARABIC("ar", "Arabic", "العربية", "🇸🇦"),
    FRENCH("fr", "French", "Français", "🇫🇷"),
    GERMAN("de", "German", "Deutsch", "🇩🇪"),
    JAPANESE("ja", "Japanese", "日本語", "🇯🇵")
}

enum class VoicePersona(val title: String, val description: String, val tone: String) {
    DEEP_DOCU("Deep & Dramatic Docu", "Authoritative, resonant, cinematic documentary voice", "Dramatic"),
    ENERGETIC_CREATOR("Viral Shorts Creator", "High-energy, punchy cadence for hook retention", "Energetic"),
    WARM_STORYTELLER("Warm Storyteller", "Calm, nuanced pacing, thoughtful, and captivating", "Warm"),
    TECH_EXPLAINER("Curious Tech Explainer", "Fast, articulate, analytical podcast style", "Analytical")
}

enum class VisualAesthetic(val title: String, val promptSuffix: String) {
    CINEMATIC_REALISM("Cinematic 8K Realism", "photorealistic 8k, unreal engine 5 render, dramatic rim lighting, photoreal depth"),
    CYBERPUNK_NEON("Dark Cyberpunk & Tech", "neon cyberpunk aesthetic, volumetric rays, dark metallic surfaces, futuristic synth"),
    ANIME_CEL("Anime & Manga Style", "vibrant anime aesthetic, Makoto Shinkai lighting, detailed cel shaded backgrounds"),
    VINTAGE_DOCU("Vintage 35mm Archive", "35mm film grain, muted warm palette, vintage archival documentary footage style"),
    MODERN_3D_MOTION("Clean 3D Minimal", "smooth isometric 3D render, minimalist studio lighting, sleek pastel textures")
}

enum class BgmStyle(val title: String, val mood: String) {
    CINEMATIC_WONDER("Cinematic Ambient", "Inspiring orchestral strings with gentle crescendo"),
    EPIC_TRAILER("Epic Tension & Bass", "Heavy cinematic braams, pulsating bass & clock tick"),
    LOFI_CHILL("Lofi Chill Beats", "Warm vinyl crackle, mellow electric piano and laid-back beat"),
    SYNTHWAVE_ENERGY("Cyber Synthwave", "80s retro synth arpeggios, driving kick and neon vibe"),
    SUSPENSE_MYSTERY("Dark Mystery Drone", "Deep ominous drones, subtle cello scrape and intrigue")
}

enum class CaptionStyle(val title: String, val description: String) {
    TIKTOK_BOUNCE("TikTok Viral Bounce", "Bold uppercase, yellow active word highlight, black border"),
    MINIMAL_CLEAN("Minimalist Subtitle", "Clean centered sans-serif on subtle glass pill"),
    KARAOKE_NEON("Cyber Neon Glow", "Glowing cyan and magenta gradient glow word by word"),
    CLASSIC_CINEMA("Cinema Box", "Subtle bottom bar letterboxed typography")
}

enum class PipelineStep(val title: String, val description: String, val percent: Float) {
    INITIALIZING("Initializing Request", "Validating topic, checking rate limits & user credits...", 0.05f),
    SCRIPTWRITING("AI Script Generation", "Writing high-retention hook, storyline beats & CTA...", 0.25f),
    STORYBOARDING("Scene Storyboarding", "Generating scene-by-scene prompts, framing & direction...", 0.45f),
    VOICE_SYNTHESIS("Voice-Over Synthesis", "Synthesizing multi-lingual natural AI voiceover...", 0.65f),
    SUBTITLE_TIMING("Subtitle Synchronization", "Generating word-level timestamp alignment & captions...", 0.80f),
    SCENE_RENDERING("Video Assembly & FX", "Assembling scenes, applying Ken Burns motion & transitions...", 0.92f),
    PACKAGING("Packaging & SEO", "Generating viral titles, tags, and clickable thumbnail...", 0.98f),
    READY("Complete Video Ready", "One topic turned into one complete video!", 1.0f)
}

data class SceneItem(
    val sceneNumber: Int,
    val headline: String,
    val narrationText: String,
    val visualPrompt: String,
    val cameraAngle: String,
    val durationSeconds: Int,
    val visualGradients: List<Long>,
    val keywordHighlights: List<String> = emptyList()
)

data class ThumbnailOption(
    val id: String,
    val headline: String,
    val subtext: String,
    val gradientStart: Long,
    val gradientEnd: Long,
    val badge: String
)

data class VideoMetadata(
    val viralTitle: String,
    val seoDescription: String,
    val hashtags: List<String>,
    val hookScore: Int,
    val estimatedRetention: String,
    val suggestedThumbnails: List<ThumbnailOption>
)

data class VideoProject(
    val id: String,
    val topic: String,
    val title: String,
    val language: SupportedLanguage,
    val duration: VideoDuration,
    val aspectRatio: AspectRatio,
    val voicePersona: VoicePersona,
    val visualStyle: VisualAesthetic,
    val bgmStyle: BgmStyle,
    val captionStyle: CaptionStyle,
    val isDemoMode: Boolean = true,
    val status: String = "READY",
    val createdAt: Long = System.currentTimeMillis(),
    val scenes: List<SceneItem> = emptyList(),
    val metadata: VideoMetadata,
    val creditCost: Int = 25,
    val videoResolution: String = "1080p FHD"
)

data class ApiKeysConfig(
    val geminiApiKey: String = "",
    val elevenLabsApiKey: String = "",
    val pexelsApiKey: String = "",
    val runwayApiKey: String = "",
    val ffmpegWorkerUrl: String = "https://render-worker.topic2video.internal",
    val demoModeOnly: Boolean = true
)

data class UserProfile(
    val id: String = "usr_creator_892",
    val email: String = "creator@topictovideo.ai",
    val displayName: String = "Video Creator Pro",
    val planType: String = "Free Tier",
    val creditsRemaining: Int = 125,
    val creditsMonthlyMax: Int = 150,
    val monthlySpendCapUsd: Double = 50.0,
    val currentSpendUsd: Double = 0.0,
    val storageUsedMb: Int = 340,
    val storageLimitMb: Int = 2048,
    val isPaymentVerified: Boolean = false,
    val apiKeysConfig: ApiKeysConfig = ApiKeysConfig()
)

data class SubscriptionPlan(
    val id: String,
    val name: String,
    val priceMonthly: Int,
    val priceAnnualMonthly: Int,
    val creditsMonthly: Int,
    val maxResolution: String,
    val maxVideoDuration: String,
    val maxConcurrentJobs: Int,
    val hasWatermark: Boolean,
    val features: List<String>,
    val isPopular: Boolean = false
)
