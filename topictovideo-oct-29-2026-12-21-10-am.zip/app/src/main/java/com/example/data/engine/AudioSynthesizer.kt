package com.example.data.engine

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import com.example.data.models.SupportedLanguage
import java.util.Locale

class VideoAudioEngine(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var onInitCallback: (() -> Unit)? = null

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("VideoAudioEngine", "TTS init failure: ${e.message}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            tts?.setPitch(0.95f)
            tts?.setSpeechRate(1.05f)
            onInitCallback?.invoke()
        } else {
            Log.w("VideoAudioEngine", "TTS initialization returned status: $status")
        }
    }

    fun speakScene(text: String, language: SupportedLanguage, onFinished: (() -> Unit)? = null) {
        if (!isInitialized || tts == null) {
            return
        }

        val targetLocale = when (language) {
            SupportedLanguage.ENGLISH -> Locale.US
            SupportedLanguage.HINDI -> Locale("hi", "IN")
            SupportedLanguage.URDU -> Locale("ur", "PK")
            SupportedLanguage.SPANISH -> Locale("es", "ES")
            SupportedLanguage.ARABIC -> Locale("ar", "SA")
            SupportedLanguage.FRENCH -> Locale.FRANCE
            SupportedLanguage.GERMAN -> Locale.GERMANY
            SupportedLanguage.JAPANESE -> Locale.JAPAN
        }

        try {
            val result = tts?.setLanguage(targetLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Graceful fallback to English if language pack not installed on emulator
                tts?.setLanguage(Locale.US)
            }
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "SCENE_AUDIO_${System.currentTimeMillis()}")
        } catch (e: Exception) {
            Log.e("VideoAudioEngine", "Error speaking text: ${e.message}")
        }
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            Log.e("VideoAudioEngine", "Error stopping TTS: ${e.message}")
        }
    }

    fun release() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            Log.e("VideoAudioEngine", "Error shutting down TTS: ${e.message}")
        }
    }
}
