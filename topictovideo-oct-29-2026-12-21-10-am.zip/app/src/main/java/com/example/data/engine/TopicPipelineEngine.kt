package com.example.data.engine

import com.example.data.models.AspectRatio
import com.example.data.models.BgmStyle
import com.example.data.models.CaptionStyle
import com.example.data.models.PipelineStep
import com.example.data.models.SceneItem
import com.example.data.models.SupportedLanguage
import com.example.data.models.ThumbnailOption
import com.example.data.models.VideoDuration
import com.example.data.models.VideoMetadata
import com.example.data.models.VideoProject
import com.example.data.models.VisualAesthetic
import com.example.data.models.VoicePersona
import kotlinx.coroutines.delay
import java.util.UUID

object TopicPipelineEngine {

    suspend fun executePipeline(
        topic: String,
        duration: VideoDuration,
        aspectRatio: AspectRatio,
        language: SupportedLanguage,
        voicePersona: VoicePersona,
        visualStyle: VisualAesthetic,
        bgmStyle: BgmStyle,
        captionStyle: CaptionStyle,
        isDemoMode: Boolean = true,
        onProgressUpdate: (PipelineStep, Float, String) -> Unit
    ): VideoProject {
        val cleanTopic = topic.trim().ifEmpty { "The Secret Origins of Artificial Intelligence" }

        // Step 1: Initializing
        onProgressUpdate(
            PipelineStep.INITIALIZING,
            0.10f,
            "Validating topic: '$cleanTopic' | Checking rate limits & API quotas..."
        )
        delay(600)

        // Step 2: Scriptwriting
        onProgressUpdate(
            PipelineStep.SCRIPTWRITING,
            0.28f,
            "Synthesizing high-retention script in ${language.englishName} (${language.nativeName}) with ${voicePersona.tone} tone..."
        )
        delay(700)

        // Step 3: Storyboarding
        onProgressUpdate(
            PipelineStep.STORYBOARDING,
            0.48f,
            "Generating ${duration.sceneCount}-scene storyboard with '${visualStyle.title}' aesthetic & cinematic framing..."
        )
        delay(700)

        // Step 4: Voice Synthesis
        onProgressUpdate(
            PipelineStep.VOICE_SYNTHESIS,
            0.68f,
            "Synthesizing AI voiceover with ${voicePersona.title} | Generating audio cadence..."
        )
        delay(700)

        // Step 5: Subtitle Timing
        onProgressUpdate(
            PipelineStep.SUBTITLE_TIMING,
            0.82f,
            "Aligning word-level timestamps for '${captionStyle.title}' animated karaoke captions..."
        )
        delay(600)

        // Step 6: Scene Rendering
        onProgressUpdate(
            PipelineStep.SCENE_RENDERING,
            0.93f,
            "Compositing scene layers, pan-zoom Ken Burns motion, and '${bgmStyle.title}' audio track..."
        )
        delay(600)

        // Step 7: Packaging & SEO
        onProgressUpdate(
            PipelineStep.PACKAGING,
            0.98f,
            "Packaging viral thumbnail, SEO tags for YouTube/Shorts, and high-CTR title..."
        )
        delay(500)

        // Build the complete VideoProject
        val project = assembleCompleteVideo(
            cleanTopic,
            duration,
            aspectRatio,
            language,
            voicePersona,
            visualStyle,
            bgmStyle,
            captionStyle,
            isDemoMode
        )

        onProgressUpdate(PipelineStep.READY, 1.0f, "One Topic → One Complete Video Generated Successfully!")
        return project
    }

    fun assembleCompleteVideo(
        topic: String,
        duration: VideoDuration,
        aspectRatio: AspectRatio,
        language: SupportedLanguage,
        voicePersona: VoicePersona,
        visualStyle: VisualAesthetic,
        bgmStyle: BgmStyle,
        captionStyle: CaptionStyle,
        isDemoMode: Boolean = true
    ): VideoProject {
        val projectId = "vid_${UUID.randomUUID().toString().take(8)}"
        val scenes = generateStoryboardScenes(topic, duration, language, visualStyle)
        val metadata = generateMetadata(topic, language, scenes)

        val durationLabel = when (duration) {
            VideoDuration.SHORT_30S -> "30s Short"
            VideoDuration.SHORT_60S -> "60s Short"
            VideoDuration.LONG_3MIN -> "3 Min Video"
            VideoDuration.LONG_5MIN -> "5 Min Deep Dive"
            VideoDuration.LONG_8MIN -> "8 Min Masterclass"
        }

        return VideoProject(
            id = projectId,
            topic = topic,
            title = metadata.viralTitle,
            language = language,
            duration = duration,
            aspectRatio = aspectRatio,
            voicePersona = voicePersona,
            visualStyle = visualStyle,
            bgmStyle = bgmStyle,
            captionStyle = captionStyle,
            isDemoMode = isDemoMode,
            status = "READY",
            createdAt = System.currentTimeMillis(),
            scenes = scenes,
            metadata = metadata,
            creditCost = duration.creditCost,
            videoResolution = if (aspectRatio == AspectRatio.VERTICAL_9_16) "1080x1920 (9:16)" else "1920x1080 (16:9)"
        )
    }

    private fun generateStoryboardScenes(
        topic: String,
        duration: VideoDuration,
        language: SupportedLanguage,
        visualStyle: VisualAesthetic
    ): List<SceneItem> {
        val count = duration.sceneCount
        val sceneDuration = duration.seconds / count

        // Color palettes for cinematic visuals
        val colorPalettes = listOf(
            listOf(0xFF1E1B4B, 0xFF312E81, 0xFF4338CA), // Deep Indigo / Cosmic
            listOf(0xFF0F172A, 0xFF1E293B, 0xFF0284C7), // Cyber Cyan / Deep Night
            listOf(0xFF3B0764, 0xFF581C87, 0xFF9333EA), // Royal Violet
            listOf(0xFF1C1917, 0xFF44403C, 0xFFB45309), // Cinematic Warm Amber
            listOf(0xFF022C22, 0xFF065F46, 0xFF10B981), // Emerald Matrix
            listOf(0xFF450A0A, 0xFF7F1D1D, 0xFFDC2626)  // Crimson Drama
        )

        val cameraAngles = listOf(
            "Ultra-wide cinematic dolly establishing shot",
            "Slow macro push-in with shallow depth of field",
            "Dynamic 45-degree low angle heroic tilt",
            "Drone aerial sweeping orbit with atmospheric haze",
            "Fast orbital tracking shot around focal subject",
            "Over-the-shoulder dramatic perspective with rim light"
        )

        return (1..count).map { index ->
            val (headline, narration) = getScriptContent(topic, index, count, language)
            val visualPrompt = "${topic.take(40)} scene $index, ${headline.lowercase()}, ${visualStyle.promptSuffix}, 8k UHD"
            val palette = colorPalettes[(index - 1) % colorPalettes.size]
            val angle = cameraAngles[(index - 1) % cameraAngles.size]

            val keywords = extractKeywords(narration)

            SceneItem(
                sceneNumber = index,
                headline = headline,
                narrationText = narration,
                visualPrompt = visualPrompt,
                cameraAngle = angle,
                durationSeconds = sceneDuration,
                visualGradients = palette,
                keywordHighlights = keywords
            )
        }
    }

    private fun extractKeywords(text: String): List<String> {
        return text.split(" ")
            .filter { it.length > 4 && !it.contains(".") }
            .take(4)
    }

    private fun getScriptContent(
        topic: String,
        sceneIndex: Int,
        totalScenes: Int,
        language: SupportedLanguage
    ): Pair<String, String> {
        return when (language) {
            SupportedLanguage.HINDI -> {
                when (sceneIndex) {
                    1 -> "रहस्यमय शुरुआत" to "क्या आप जानते हैं कि $topic के पीछे की असली कहानी क्या है? आज हम वो सच उजागर कर रहे हैं जो इतिहास ने छुपाया था!"
                    2 -> "गहराता रहस्य" to "दशकों से विशेषज्ञों ने $topic को समझने की कोशिश की, लेकिन सबूतों ने सबको हैरान कर दिया।"
                    totalScenes -> "अंतिम निष्कर्ष और सवाल" to "तो क्या $topic दुनिया का सबसे बड़ा रहस्य है? अपनी राय कमेंट में बताएं और सब्सक्राइब करें!"
                    else -> "अनसुलझे तथ्य" to "$topic की गहराई में जाते ही ऐसे सबूत मिलते हैं जिन्हें विज्ञान भी पूरी तरह से नहीं समझा पाया है।"
                }
            }
            SupportedLanguage.URDU -> {
                when (sceneIndex) {
                    1 -> "حیران کن آغاز" to "کیا آپ جانتے ہیں کہ $topic کی اصل حقیقت کیا ہے؟ آج ہم وہ راز کھولیں گے جو دنیا سے چھپایا گیا تھا!"
                    2 -> "کھوج اور شواہد" to "برسوں کی تحقیق کے بعد $topic کے بارے میں جو انکشافات ہوئے ہیں وہ رونگٹے کھڑے کر دیتے ہیں۔"
                    totalScenes -> "حتمی نتیجہ اور رائے" to "کیا آپ کے خیال میں $topic سچ ہے؟ اپنی رائے نیچے کمنٹ کریں اور فالو کرنا نہ بھولیں!"
                    else -> "پراسرار حقائق" to "$topic کی کہانی میں ایسے موڑ آتے ہیں جس نے بڑے بڑے محققین کو ششدر کر دیا۔"
                }
            }
            SupportedLanguage.SPANISH -> {
                when (sceneIndex) {
                    1 -> "El Gran Gancho" to "¿Sabías que detrás de $topic se esconde un misterio que casi nadie conoce? Quédate hasta el final para descubrirlo."
                    2 -> "La Evidencia Oculta" to "Durante décadas, los investigadores intentaron descifrar los patrones de $topic con resultados asombrosos."
                    totalScenes -> "El Veredicto Final" to "¿Crees que $topic cambiará el futuro? Déjame tu opinión en los comentarios y suscríbete para más."
                    else -> "El Giro Inesperado" to "Justo cuando creían tener la respuesta, un nuevo descubrimiento sobre $topic lo cambió absolutamente todo."
                }
            }
            SupportedLanguage.ARABIC -> {
                when (sceneIndex) {
                    1 -> "المقدمة المشوقة" to "هل تعلم الحقيقة الصادمة وراء $topic؟ في هذا الفيديو، نكشف الأسرار التي لم يخبرك بها أحد!"
                    2 -> "الأدلة والغموض" to "لسنوات طويلة، حيرت ظاهرة $topic العلماء والمكتشفين حول العالم."
                    totalScenes -> "الخلاصة والاشتراك" to "ما هو رأيك في $topic؟ شاركنا وجهة نظرك في التعليقات واشترك للمزيد من الأسرار!"
                    else -> "الحقائق المذهلة" to "كلما تعمقنا أكثر في $topic، كلما اكتشفنا تفاصيل لا تصدق."
                }
            }
            else -> {
                when (sceneIndex) {
                    1 -> "The Viral Hook" to "You won't believe what happens when you look closely at $topic. Almost everyone gets this completely backwards!"
                    2 -> "The Hidden Truth" to "For years, conventional wisdom told us one thing about $topic. But recently declassified documents revealed something shocking."
                    3 -> "The Turning Point" to "Engineers and researchers tracked the anomaly down to a single pivotal moment that changed $topic forever."
                    totalScenes -> "The Verdict & CTA" to "Is $topic the greatest breakthrough of our lifetime? Drop your thoughts below and hit follow for part two!"
                    else -> "The Evidence Unfolds" to "When you break down the real mechanics of $topic, the numbers simply don't add up to what we were told."
                }
            }
        }
    }

    private fun generateMetadata(
        topic: String,
        language: SupportedLanguage,
        scenes: List<SceneItem>
    ): VideoMetadata {
        val viralTitle = when (language) {
            SupportedLanguage.HINDI -> "$topic का सबसे बड़ा रहस्य जो छुपाया गया था! 😱"
            SupportedLanguage.URDU -> "$topic کی وہ خوفناک حقیقت جو کسی کو معلوم نہیں! ⚠️"
            SupportedLanguage.SPANISH -> "¡La Verdad Prohibida Sobre $topic Revelada! 🚨"
            SupportedLanguage.ARABIC -> "الحقيقة الخفية وراء $topic التي صدمت الجميع! ⚡"
            else -> "The Terrifying Secret Behind $topic (NOBODY TALKS ABOUT THIS)"
        }

        val tagPrefix = topic.replace(" ", "").take(12)
        val hashtags = listOf(
            "#$tagPrefix",
            "#AIContent",
            "#ViralVideo",
            "#Storytelling",
            "#Shorts",
            "#TopicToVideo",
            "#DeepDive"
        )

        val seoDescription = """
            Full investigation into '$topic'.
            In this video, we break down scene-by-scene the hidden truths, verified facts, and mind-bending reality of $topic.
            
            ⏱️ Timestamps:
            ${scenes.mapIndexed { idx, sc -> "00:${(idx * sc.durationSeconds).toString().padStart(2, '0')} - ${sc.headline}" }.joinToString("\n")}
            
            Generated with TopicToVideo AI SaaS.
        """.trimIndent()

        val thumbnails = listOf(
            ThumbnailOption(
                id = "th_1",
                headline = "THEY LIED ABOUT THIS!",
                subtext = topic.take(24).uppercase(),
                gradientStart = 0xFF7F1D1D,
                gradientEnd = 0xFF1C1917,
                badge = "98% CTR VIRAL HOOK"
            ),
            ThumbnailOption(
                id = "th_2",
                headline = "100% EXPLAINED",
                subtext = "WHAT REALLY HAPPENED",
                gradientStart = 0xFF1E1B4B,
                gradientEnd = 0xFF0284C7,
                badge = "DEEP DIVE"
            ),
            ThumbnailOption(
                id = "th_3",
                headline = "DONT MISS THIS",
                subtext = "THE FULL TRUTH",
                gradientStart = 0xFF3B0764,
                gradientEnd = 0xFFBE185D,
                badge = "TRENDING"
            )
        )

        return VideoMetadata(
            viralTitle = viralTitle,
            seoDescription = seoDescription,
            hashtags = hashtags,
            hookScore = 94,
            estimatedRetention = "78% Avg Watch Time (Top 5% on Shorts)",
            suggestedThumbnails = thumbnails
        )
    }
}
